$(document).ready(function() {
	$('#fullpage').fullpage();
});